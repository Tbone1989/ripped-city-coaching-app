import type { Testimonial } from '../types.ts';

export const mockTestimonials: Testimonial[] = [
  {
    name: "John D.",
    quote: "Working with Tyrone completely changed my perspective on fitness. The custom plans were a game-changer, and the personal support was incredible. I lost 40 pounds and feel amazing!",
    imageUrl: "https://picsum.photos/seed/client1/100/100"
  },
  {
    name: "Sarah K.",
    quote: "I've tried so many programs, but this is the first one that stuck. The combination of data-driven plans and genuine encouragement made all the difference. I'm stronger than I've ever been.",
    imageUrl: "https://picsum.photos/seed/client2/100/100"
  },
  {
    name: "Mike R.",
    quote: "As someone with a busy schedule, the efficiency of this program was key. The workouts were tough but effective, and the meal plans were easy to follow. Highly recommend!",
    imageUrl: "https://picsum.photos/seed/client3/100/100"
  }
];