import { createClient } from '@supabase/supabase-js';
import type { Client } from '../types.ts';

// Manually define Json type to circumvent potential import issues with some bundlers/TypeScript versions.
// The recursive definition was causing "Type instantiation is excessively deep" errors.
// Simplifying to `any` for the database boundary resolves the compiler issue.
type Json = any;

// By defining a specific 'ClientRow' for Supabase with 'Json' for complex types,
// we prevent the "type instantiation is excessively deep" error. The rest of the app
// can still use the fully-typed 'Client' interface by casting the results from Supabase.
export type ClientRow = {
  id: string;
  created_at: string;
  name: string;
  email: string;
  goal: string;
  status: 'prospect' | 'active' | 'inactive';
  paymentStatus?: 'unpaid' | 'paid';
  profile: Json;
  intakeData: Json;
  progress: Json;
  generatedPlans: Json;
  payments: Json;
  communication: Json;
  bloodworkHistory: Json;
  clientTestimonials: Json;
  bloodDonationStatus: Json;
  holisticHealth: Json;
};

// Define explicit Insert and Update types to reduce TS compiler complexity
export type ClientInsert = Omit<ClientRow, 'id' | 'created_at'>;
export type ClientUpdate = Partial<Omit<ClientRow, 'id'>>;


export type Database = {
  public: {
    Tables: {
      clients: {
        Row: ClientRow;
        Insert: ClientInsert;
        Update: ClientUpdate;
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

const supabaseUrl = 'https://neyopskwxstqpoogqumy.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5leW9wc2t3eHN0cXBvb2dxdW15Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ2MjU3NDIsImV4cCI6MjA3MDIwMTc0Mn0.rQI9MF7dyt0Zn0JzvNuZp7cK46yZ7GeS6eSl9YzBCsA';

export const isSupabaseConfigured = !!(supabaseUrl && supabaseAnonKey);

export const supabase = createClient<Database>(
  supabaseUrl,
  supabaseAnonKey
);